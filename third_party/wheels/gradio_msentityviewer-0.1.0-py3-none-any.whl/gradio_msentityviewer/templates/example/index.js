import { a as e, c as t, i as n, n as r, o as i, s as a } from "./index-client-BRjXDUpI.js";
//#region frontend/Example.svelte
var o = e("<pre> </pre>");
function s(e, s) {
	var c = o(), l = a(c, !0);
	t(c), i((e) => r(l, e), [() => JSON.stringify(s.value, null, 2)]), n(e, c);
}
//#endregion
export { s as default };
