//#region frontend/node_modules/svelte/src/internal/shared/utils.js
var e = Array.isArray, t = Array.prototype.indexOf, n = Array.prototype.includes, r = Array.from, i = Object.defineProperty, a = Object.getOwnPropertyDescriptor, o = Object.prototype, s = Array.prototype, c = Object.getPrototypeOf, l = Object.isExtensible, u = () => {};
function d(e) {
	for (var t = 0; t < e.length; t++) e[t]();
}
function f() {
	var e, t;
	return {
		promise: new Promise((n, r) => {
			e = n, t = r;
		}),
		resolve: e,
		reject: t
	};
}
var p = 1024, m = 2048, h = 4096, ee = 8192, te = 16384, ne = 32768, re = 1 << 25, ie = 65536, g = 1 << 19, ae = 1 << 20, _ = 65536, oe = 1 << 21, se = 1 << 22, ce = 1 << 23, le = Symbol("$state"), ue = Symbol("attributes"), de = Symbol("class"), fe = Symbol("style"), pe = Symbol("text"), v = new class extends Error {
	name = "StaleReactionError";
	message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
globalThis.document?.contentType;
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/errors.js
function me() {
	throw Error("https://svelte.dev/e/async_derived_orphan");
}
function he() {
	throw Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function ge() {
	throw Error("https://svelte.dev/e/state_descriptors_fixed");
}
function _e() {
	throw Error("https://svelte.dev/e/state_prototype_fixed");
}
function ve() {
	throw Error("https://svelte.dev/e/state_unsafe_mutation");
}
function ye() {
	throw Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
//#endregion
//#region frontend/node_modules/svelte/src/constants.js
var y = Symbol("uninitialized");
function be() {
	console.warn("https://svelte.dev/e/derived_inert");
}
function xe() {
	console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function Se(e) {}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/equality.js
function Ce(e) {
	return e === this.v;
}
function we(e, t) {
	return e == e ? e !== t || typeof e == "object" && !!e || typeof e == "function" : t == t;
}
function Te(e) {
	return !we(e, this.v);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/context.js
var b = null;
function x(e) {
	b = e;
}
function Ee(e, t = !1, n) {
	b = {
		p: b,
		i: !1,
		c: null,
		e: null,
		s: e,
		x: null,
		r: W,
		l: null
	};
}
function De(e) {
	var t = b, n = t.e;
	if (n !== null) {
		t.e = null;
		for (var r of n) kt(r);
	}
	return e !== void 0 && (t.x = e), t.i = !0, b = t.p, e ?? {};
}
function S() {
	return !0;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/task.js
var C = [];
function Oe() {
	var e = C;
	C = [], d(e);
}
function w(e) {
	if (C.length === 0 && !$e) {
		var t = C;
		queueMicrotask(() => {
			t === C && Oe();
		});
	}
	C.push(e);
}
function ke(e) {
	var t = W;
	if (t === null) return V.f |= ce, e;
	if (!(t.f & 32768) && !(t.f & 4)) throw e;
	T(e, t);
}
function T(e, t) {
	if (!(t !== null && t.f & 16384)) {
		for (; t !== null;) {
			if (t.f & 128) {
				if (!(t.f & 32768)) throw e;
				try {
					t.b.error(e);
					return;
				} catch (t) {
					e = t;
				}
			}
			t = t.parent;
		}
		throw e;
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/status.js
var Ae = ~(m | h | p);
function E(e, t) {
	e.f = e.f & Ae | t;
}
function je(e) {
	e.f & 512 || e.deps === null ? E(e, p) : E(e, h);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/utils.js
function Me(e) {
	if (e !== null) for (let t of e) !(t.f & 2) || !(t.f & 65536) || (t.f ^= _, Me(t.deps));
}
function Ne(e, t, n) {
	e.f & 2048 ? t.add(e) : e.f & 4096 && n.add(e), Me(e.deps), E(e, p);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/elements/bindings/shared.js
function Pe(e) {
	var t = V, n = W;
	U(null), G(null);
	try {
		return e();
	} finally {
		U(t), G(n);
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/reactivity/create-subscriber.js
function Fe(e) {
	let t = 0, n = ft(0), r;
	return () => {
		Dt() && ($(n), Mt(() => (t === 0 && (r = on(() => e(() => I(n)))), t += 1, () => {
			w(() => {
				--t, t === 0 && (r?.(), r = void 0, I(n));
			});
		})));
	};
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/blocks/boundary.js
var Ie = ie | g;
function Le(e, t, n, r) {
	new Re(e, t, n, r);
}
var Re = class {
	parent;
	is_pending = !1;
	transform_error;
	#e;
	#t;
	#n;
	#r;
	#i = null;
	#a = null;
	#o = null;
	#s = null;
	#c = 0;
	#l = 0;
	#u = !1;
	#d = /* @__PURE__ */ new Set();
	#f = /* @__PURE__ */ new Set();
	#p = null;
	#m = Fe(() => (this.#p = ft(this.#c), () => {
		this.#p = null;
	}));
	constructor(e, t, n, r) {
		this.#e = e, this.#t = t, this.#n = (e) => {
			var t = W;
			t.b = this, t.f |= 128, n(e);
		}, this.parent = W.b, this.transform_error = r ?? this.parent?.transform_error ?? ((e) => e), this.#r = Pt(() => {
			this.#g();
		}, Ie);
	}
	#h(e) {
		var t = !1, n = !1;
		let r = () => {
			if (t) {
				xe();
				return;
			}
			t = !0, n && ye(), this.#o !== null && Vt(this.#o, () => {
				this.#o = null;
			}), this.#v(() => {
				this.#g();
			});
		};
		return {
			reset: r,
			invoke_onerror: () => {
				try {
					n = !0, this.#t.onerror?.(e, r), n = !1;
				} catch (e) {
					T(e, this.#r && this.#r.parent);
				}
			}
		};
	}
	#g() {
		try {
			if (this.is_pending = this.has_pending_snippet(), this.#l = 0, this.#c = 0, this.#i = Ft(() => {
				this.#n(this.#e);
			}), this.#l > 0) {
				var e = this.#s = document.createDocumentFragment();
				Ut(this.#i, e);
				let t = this.#t.pending;
				this.#a = Ft(() => t(this.#e));
			} else this.#_(k);
		} catch (e) {
			this.error(e);
		}
	}
	#_(e) {
		this.is_pending = !1, e.transfer_effects(this.#d, this.#f);
	}
	defer_effect(e) {
		Ne(e, this.#d, this.#f);
	}
	is_rendered() {
		return !this.is_pending && (!this.parent || this.parent.is_rendered());
	}
	has_pending_snippet() {
		return !!this.#t.pending;
	}
	#v(e) {
		var t = W, n = V, r = b;
		G(this.#r), U(this.#r), x(this.#r.ctx);
		try {
			return it.ensure(), e();
		} catch (e) {
			return ke(e), null;
		} finally {
			G(t), U(n), x(r);
		}
	}
	#y(e, t) {
		if (!this.has_pending_snippet()) {
			this.parent && this.parent.#y(e, t);
			return;
		}
		this.#l += e, this.#l === 0 && (this.#_(t), this.#a && Vt(this.#a, () => {
			this.#a = null;
		}), this.#s &&= (this.#e.before(this.#s), null));
	}
	update_pending_count(e, t) {
		this.#y(e, t), this.#c += e, !(!this.#p || this.#u) && (this.#u = !0, w(() => {
			this.#u = !1, this.#p && pt(this.#p, this.#c);
		}));
	}
	get_effect_pending() {
		return this.#m(), $(this.#p);
	}
	error(e) {
		if (!this.#t.onerror && !this.#t.failed) throw e;
		k?.is_fork ? (this.#i && k.skip_effect(this.#i), this.#a && k.skip_effect(this.#a), this.#o && k.skip_effect(this.#o), k.oncommit(() => {
			this.#b(e);
		})) : this.#b(e);
	}
	#b(e) {
		this.#i &&= (z(this.#i), null), this.#a &&= (z(this.#a), null), this.#o &&= (z(this.#o), null);
		let t = this.#t.failed, n = (e) => {
			let { reset: n, invoke_onerror: r } = this.#h(e);
			r(), t && (this.#o = this.#v(() => {
				try {
					return Ft(() => {
						var r = W;
						r.b = this, r.f |= 128, t(this.#e, () => e, () => n);
					});
				} catch (e) {
					return T(e, this.#r.parent), null;
				}
			}));
		};
		w(() => {
			var t;
			try {
				t = this.transform_error(e);
			} catch (e) {
				T(e, this.#r && this.#r.parent);
				return;
			}
			typeof t == "object" && t && typeof t.then == "function" ? t.then(n, (e) => T(e, this.#r && this.#r.parent)) : n(t);
		});
	}
};
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/async.js
function ze(e, t, n, r) {
	let i = S() ? Ue : Ge;
	var a = e.filter((e) => !e.settled), o = t.map(i);
	if (n.length === 0 && a.length === 0) {
		r(o);
		return;
	}
	var s = W, c = Be(), l = a.length === 1 ? a[0].promise : a.length > 1 ? Promise.all(a.map((e) => e.promise)) : null;
	function u(e) {
		if (!(s.f & 16384)) {
			c();
			try {
				r([...o, ...e]);
			} catch (e) {
				T(e, s);
			}
			Ve();
		}
	}
	var d = He();
	if (n.length === 0) {
		l.then(() => u([])).finally(d);
		return;
	}
	function f() {
		Promise.all(n.map((e) => /* @__PURE__ */ We(e))).then(u).catch((e) => T(e, s)).finally(d);
	}
	l ? l.then(() => {
		c(), f(), Ve();
	}) : f();
}
function Be() {
	var e = W, t = V, n = b, r = k;
	return function(i = !0) {
		G(e), U(t), x(n), i && !(e.f & 16384) && (r?.activate(), r?.apply());
	};
}
function Ve(e = !0) {
	G(null), U(null), x(null), e && k?.deactivate();
}
function He() {
	var e = W, t = e.b, n = k, r = !!t?.is_rendered();
	return t?.update_pending_count(1, n), n.increment(r, e), () => {
		t?.update_pending_count(-1, n), n.decrement(r, e);
	};
}
/*#__NO_SIDE_EFFECTS__*/
function Ue(e) {
	var t = 2 | m;
	return W !== null && (W.f |= g), {
		ctx: b,
		deps: null,
		effects: null,
		equals: Ce,
		f: t,
		fn: e,
		reactions: null,
		rv: 0,
		v: y,
		wv: 0,
		parent: W,
		ac: null
	};
}
var D = Symbol("obsolete");
/*#__NO_SIDE_EFFECTS__*/
function We(e, t, n) {
	let r = W;
	r === null && me();
	var i = void 0, a = ft(y), o = !V, s = /* @__PURE__ */ new Set();
	return jt(() => {
		var t = W, n = f();
		i = n.promise;
		try {
			Promise.resolve(e()).then(n.resolve, (e) => {
				e !== v && n.reject(e);
			}).finally(Ve);
		} catch (e) {
			n.reject(e), Ve();
		}
		var c = k;
		if (o) {
			if (t.f & 32768) var l = He();
			if (r.b?.is_rendered()) c.async_deriveds.get(t)?.reject(D);
			else for (let e of s.values()) e.reject(D);
			s.add(n), c.async_deriveds.set(t, n);
		}
		let u = (e, t = void 0) => {
			l?.(), s.delete(n), t !== D && (c.activate(), t ? (a.f |= ce, pt(a, t)) : (a.f & 8388608 && (a.f ^= ce), pt(a, e)), c.deactivate());
		};
		n.promise.then(u, (e) => u(null, e || "unknown"));
	}), Ot(() => {
		for (let e of s) e.reject(D);
	}), new Promise((e) => {
		function t(n) {
			function r() {
				n === i ? e(a) : t(i);
			}
			n.then(r, r);
		}
		t(i);
	});
}
/*#__NO_SIDE_EFFECTS__*/
function Ge(e) {
	let t = /* @__PURE__ */ Ue(e);
	return t.equals = Te, t;
}
function Ke(e) {
	var t = e.effects;
	if (t !== null) {
		e.effects = null;
		for (var n = 0; n < t.length; n += 1) z(t[n]);
	}
}
function qe(e) {
	var t, n = W, r = e.parent;
	if (!B && r !== null && e.v !== y && r.f & 24576) return be(), e.v;
	G(r);
	try {
		e.f &= ~_, Ke(e), t = en(e);
	} finally {
		G(n);
	}
	return t;
}
function Je(e) {
	var t = qe(e);
	if (!e.equals(t) && (e.wv = Zt(), (!k?.is_fork || e.deps === null) && (k === null ? e.v = t : (k.capture(e, t, !0), Ze?.capture(e, t, !0)), e.deps === null))) {
		E(e, p);
		return;
	}
	B || (A === null ? je(e) : (Dt() || k?.is_fork) && A.set(e, t));
}
function Ye(e) {
	if (e.effects !== null) for (let t of e.effects) (t.teardown || t.ac) && (t.teardown?.(), t.ac !== null && Pe(() => {
		t.ac.abort(v), t.ac = null;
	}), t.fn !== null && (t.teardown = u), nn(t, 0), Lt(t));
}
function Xe(e) {
	if (e.effects !== null) for (let t of e.effects) t.teardown && t.fn !== null && Q(t);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/batch.js
var O = null, k = null, Ze = null, A = null, Qe = null, $e = !1, et = !1, j = null, tt = null, nt = 0, rt = 1, it = class e {
	id = rt++;
	#e = !1;
	linked = !0;
	#t = null;
	#n = null;
	async_deriveds = /* @__PURE__ */ new Map();
	current = /* @__PURE__ */ new Map();
	previous = /* @__PURE__ */ new Map();
	#r = /* @__PURE__ */ new Set();
	#i = /* @__PURE__ */ new Set();
	#a = 0;
	#o = /* @__PURE__ */ new Map();
	#s = null;
	#c = [];
	#l = [];
	#u = /* @__PURE__ */ new Set();
	#d = /* @__PURE__ */ new Set();
	#f = /* @__PURE__ */ new Map();
	#p = /* @__PURE__ */ new Set();
	is_fork = !1;
	#m = !1;
	constructor() {
		O === null ? O = this : (O.#n = this, this.#t = O), O = this;
	}
	#h() {
		if (this.is_fork) return !0;
		for (let n of this.#o.keys()) {
			for (var e = n, t = !1; e.parent !== null;) {
				if (this.#f.has(e)) {
					t = !0;
					break;
				}
				e = e.parent;
			}
			if (!t) return !0;
		}
		return !1;
	}
	skip_effect(e) {
		this.#f.has(e) || this.#f.set(e, {
			d: [],
			m: []
		}), this.#p.delete(e);
	}
	unskip_effect(e, t = (e) => this.schedule(e)) {
		var n = this.#f.get(e);
		if (n) {
			this.#f.delete(e);
			for (var r of n.d) E(r, m), t(r);
			for (r of n.m) E(r, h), t(r);
		}
		this.#p.add(e);
	}
	#g() {
		this.#e = !0, nt++ > 1e3 && (this.#x(), at());
		for (let e of this.#u) this.#d.delete(e), E(e, m), this.schedule(e);
		for (let e of this.#d) E(e, h), this.schedule(e);
		let t = this.#c;
		this.#c = [], this.apply();
		var n = j = [], r = [], i = tt = [];
		for (let e of t) try {
			this.#_(e, n, r);
		} catch (t) {
			throw lt(e), this.#h() || this.discard(), t;
		}
		if (k = null, i.length > 0) {
			var a = e.ensure();
			for (let e of i) a.schedule(e);
		}
		if (j = null, tt = null, this.#h()) {
			this.#b(r), this.#b(n);
			for (let [e, t] of this.#f) ct(e, t);
			i.length > 0 && k.#g();
			return;
		}
		let o = this.#v();
		if (o) {
			this.#b(r), this.#b(n), o.#y(this);
			return;
		}
		this.#u.clear(), this.#d.clear();
		for (let e of this.#r) e(this);
		this.#r.clear(), Ze = this, ot(r), ot(n), Ze = null, this.#s?.resolve();
		var s = k;
		if (this.#a === 0 && (this.#c.length === 0 || s !== null) && this.#x(), this.#c.length > 0) {
			if (s !== null) {
				let e = s;
				e.#c.push(...this.#c.filter((t) => !e.#c.includes(t)));
			} else s = this;
		}
		s !== null && s.#g();
	}
	#_(e, t, n) {
		e.f ^= p;
		for (var r = e.first; r !== null;) {
			var i = r.f, a = !!(i & 96);
			if (!(a && i & 1024 || i & 8192 || this.#f.has(r)) && r.fn !== null) {
				a ? r.f ^= p : i & 4 ? t.push(r) : Qt(r) && (i & 16 && this.#d.add(r), Q(r));
				var o = r.first;
				if (o !== null) {
					r = o;
					continue;
				}
			}
			for (; r !== null;) {
				var s = r.next;
				if (s !== null) {
					r = s;
					break;
				}
				r = r.parent;
			}
		}
	}
	#v() {
		for (var e = this.#t; e !== null;) {
			if (!e.is_fork) {
				for (let [t, [, n]] of this.current) if (e.current.has(t) && !n) return e;
			}
			e = e.#t;
		}
		return null;
	}
	#y(e) {
		for (let [t, n] of e.current) !this.previous.has(t) && e.previous.has(t) && this.previous.set(t, e.previous.get(t)), this.current.set(t, n);
		for (let [t, n] of e.async_deriveds) {
			let e = this.async_deriveds.get(t);
			e && n.promise.then(e.resolve).catch(e.reject);
		}
		e.async_deriveds.clear(), this.transfer_effects(e.#u, e.#d);
		let t = (e) => {
			var n = e.reactions;
			if (n !== null && !(e.f & 2 && !(e.f & 6144))) for (let e of n) {
				var r = e.f;
				if (r & 2) t(e);
				else {
					var i = e;
					r & 4194320 && !this.async_deriveds.has(i) && (this.#d.delete(i), E(i, m), this.schedule(i));
				}
			}
		};
		for (let e of this.current.keys()) t(e);
		this.oncommit(() => e.discard()), e.#x(), k = this, this.#g();
	}
	#b(e) {
		for (var t = 0; t < e.length; t += 1) Ne(e[t], this.#u, this.#d);
	}
	capture(e, t, n = !1) {
		e.v !== y && !this.previous.has(e) && this.previous.set(e, e.v), e.f & 8388608 || (this.current.set(e, [t, n]), A?.set(e, t)), this.is_fork || (e.v = t);
	}
	activate() {
		k = this;
	}
	deactivate() {
		k = null, A = null;
	}
	flush() {
		try {
			et = !0, k = this, this.#g();
		} finally {
			nt = 0, Qe = null, j = null, tt = null, et = !1, k = null, A = null, N.clear();
		}
	}
	discard() {
		for (let e of this.#i) e(this);
		this.#i.clear();
		for (let e of this.async_deriveds.values()) e.reject(D);
		this.#x(), this.#s?.resolve();
	}
	register_created_effect(e) {
		this.#l.push(e);
	}
	increment(e, t) {
		if (this.#a += 1, e) {
			let e = this.#o.get(t) ?? 0;
			this.#o.set(t, e + 1);
		}
	}
	decrement(e, t) {
		if (--this.#a, e) {
			let e = this.#o.get(t) ?? 0;
			e === 1 ? this.#o.delete(t) : this.#o.set(t, e - 1);
		}
		this.#m || (this.#m = !0, w(() => {
			this.#m = !1, this.linked && this.flush();
		}));
	}
	transfer_effects(e, t) {
		for (let t of e) this.#u.add(t);
		for (let e of t) this.#d.add(e);
		e.clear(), t.clear();
	}
	oncommit(e) {
		this.#r.add(e);
	}
	ondiscard(e) {
		this.#i.add(e);
	}
	settled() {
		return (this.#s ??= f()).promise;
	}
	static ensure() {
		if (k === null) {
			let t = k = new e();
			!et && w(() => {
				t.#e || t.flush();
			});
		}
		return k;
	}
	apply() {
		A = null;
	}
	schedule(e) {
		if (Qe = e, e.b?.is_pending && e.f & 16777228 && !(e.f & 32768)) {
			e.b.defer_effect(e);
			return;
		}
		for (var t = e; t.parent !== null;) {
			t = t.parent;
			var n = t.f;
			if (j !== null && t === W && (V === null || !(V.f & 2))) return;
			if (n & 96) {
				if (!(n & 1024)) return;
				t.f ^= p;
			}
		}
		this.#c.push(t);
	}
	#x() {
		if (this.linked) {
			var e = this.#t, t = this.#n;
			e === null || (e.#n = t), t === null ? O = e : t.#t = e, this.linked = !1;
		}
	}
};
function at() {
	try {
		he();
	} catch (e) {
		T(e, Qe);
	}
}
var M = null;
function ot(e) {
	var t = e.length;
	if (t !== 0) {
		for (var n = 0; n < t;) {
			var r = e[n++];
			if (!(r.f & 24576) && Qt(r) && (M = /* @__PURE__ */ new Set(), Q(r), r.deps === null && r.first === null && r.nodes === null && r.teardown === null && r.ac === null && Bt(r), M?.size > 0)) {
				N.clear();
				for (let e of M) {
					if (e.f & 24576) continue;
					let t = [e], n = e.parent;
					for (; n !== null;) M.has(n) && (M.delete(n), t.push(n)), n = n.parent;
					for (let e = t.length - 1; e >= 0; e--) {
						let n = t[e];
						n.f & 24576 || Q(n);
					}
				}
				M.clear();
			}
		}
		M = null;
	}
}
function st(e) {
	k.schedule(e);
}
function ct(e, t) {
	if (!(e.f & 32 && e.f & 1024)) {
		e.f & 2048 ? t.d.push(e) : e.f & 4096 && t.m.push(e), E(e, p);
		for (var n = e.first; n !== null;) ct(n, t), n = n.next;
	}
}
function lt(e) {
	E(e, p);
	for (var t = e.first; t !== null;) lt(t), t = t.next;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/sources.js
var ut = /* @__PURE__ */ new Set(), N = /* @__PURE__ */ new Map(), dt = !1;
function ft(e, t) {
	return {
		f: 0,
		v: e,
		reactions: null,
		equals: Ce,
		rv: 0,
		wv: 0
	};
}
/*#__NO_SIDE_EFFECTS__*/
function P(e, t) {
	let n = ft(e, t);
	return qt(n), n;
}
function F(e, t, n = !1) {
	return V !== null && (!H || V.f & 131072) && S() && V.f & 4325394 && (K === null || !K.has(e)) && ve(), pt(e, n ? L(t) : t, tt);
}
function pt(e, t, n = null) {
	if (!e.equals(t)) {
		N.set(e, B ? t : e.v);
		var r = it.ensure();
		if (r.capture(e, t), e.f & 2) {
			let t = e;
			e.f & 2048 && qe(t), A === null && je(t);
		}
		e.wv = Zt(), ht(e, m, n), S() && W !== null && W.f & 1024 && !(W.f & 96) && (Y === null ? Jt([e]) : Y.push(e)), !r.is_fork && ut.size > 0 && !dt && mt();
	}
	return t;
}
function mt() {
	dt = !1;
	for (let e of ut) {
		e.f & 1024 && E(e, h);
		let t;
		try {
			t = Qt(e);
		} catch {
			t = !0;
		}
		t && Q(e);
	}
	ut.clear();
}
function I(e) {
	F(e, e.v + 1);
}
function ht(e, t, n) {
	var r = e.reactions;
	if (r !== null) for (var i = S(), a = r.length, o = 0; o < a; o++) {
		var s = r[o], c = s.f;
		if (!(!i && s === W)) {
			var l = (c & m) === 0;
			if (l && E(s, t), c & 131072) ut.add(s);
			else if (c & 2) {
				var u = s;
				A?.delete(u), c & 65536 || (c & 512 && (W === null || !(W.f & 2097152)) && (s.f |= _), ht(u, h, n));
			} else if (l) {
				var d = s;
				c & 16 && M !== null && M.add(d), n === null ? st(d) : n.push(d);
			}
		}
	}
}
function L(t) {
	if (typeof t != "object" || !t || le in t) return t;
	let n = c(t);
	if (n !== o && n !== s) return t;
	var r = /* @__PURE__ */ new Map(), i = e(t), l = /* @__PURE__ */ P(0), u = null, d = Z, f = (e) => {
		if (Z === d) return e();
		var t = V, n = Z;
		U(null), Xt(d);
		var r = e();
		return U(t), Xt(n), r;
	};
	return i && r.set("length", /* @__PURE__ */ P(t.length, u)), new Proxy(t, {
		defineProperty(e, t, n) {
			(!("value" in n) || n.configurable === !1 || n.enumerable === !1 || n.writable === !1) && ge();
			var i = r.get(t);
			return i === void 0 ? f(() => {
				var e = /* @__PURE__ */ P(n.value, u);
				return r.set(t, e), e;
			}) : F(i, n.value, !0), !0;
		},
		deleteProperty(e, t) {
			var n = r.get(t);
			if (n === void 0) {
				if (t in e) {
					let e = f(() => /* @__PURE__ */ P(y, u));
					r.set(t, e), I(l);
				}
			} else F(n, y), I(l);
			return !0;
		},
		get(e, n, i) {
			if (n === le) return t;
			var o = r.get(n), s = n in e;
			if (o === void 0 && (!s || a(e, n)?.writable) && (o = f(() => /* @__PURE__ */ P(L(s ? e[n] : y), u)), r.set(n, o)), o !== void 0) {
				var c = $(o);
				return c === y ? void 0 : c;
			}
			return Reflect.get(e, n, i);
		},
		getOwnPropertyDescriptor(e, t) {
			var n = Reflect.getOwnPropertyDescriptor(e, t);
			if (n && "value" in n) {
				var i = r.get(t);
				i && (n.value = $(i));
			} else if (n === void 0) {
				var a = r.get(t), o = a?.v;
				if (a !== void 0 && o !== y) return {
					enumerable: !0,
					configurable: !0,
					value: o,
					writable: !0
				};
			}
			return n;
		},
		has(e, t) {
			if (t === le) return !0;
			var n = r.get(t), i = n !== void 0 && n.v !== y || Reflect.has(e, t);
			return (n !== void 0 || W !== null && (!i || a(e, t)?.writable)) && (n === void 0 && (n = f(() => /* @__PURE__ */ P(i ? L(e[t]) : y, u)), r.set(t, n)), $(n) === y) ? !1 : i;
		},
		set(e, t, n, o) {
			var s = r.get(t), c = t in e;
			if (i && t === "length") for (var d = n; d < s.v; d += 1) {
				var p = r.get(d + "");
				p === void 0 ? d in e && (p = f(() => /* @__PURE__ */ P(y, u)), r.set(d + "", p)) : F(p, y);
			}
			if (s === void 0) (!c || a(e, t)?.writable) && (s = f(() => /* @__PURE__ */ P(void 0, u)), F(s, L(n)), r.set(t, s));
			else {
				c = s.v !== y;
				var m = f(() => L(n));
				F(s, m);
			}
			var h = Reflect.getOwnPropertyDescriptor(e, t);
			if (h?.set && h.set.call(o, n), !c) {
				if (i && typeof t == "string") {
					var ee = r.get("length"), te = Number(t);
					Number.isInteger(te) && te >= ee.v && F(ee, te + 1);
				}
				I(l);
			}
			return !0;
		},
		ownKeys(e) {
			$(l);
			var t = Reflect.ownKeys(e).filter((e) => {
				var t = r.get(e);
				return t === void 0 || t.v !== y;
			});
			for (var [n, i] of r) i.v !== y && !(n in e) && t.push(n);
			return t;
		},
		setPrototypeOf() {
			_e();
		}
	});
}
var gt, _t, vt, yt;
function bt() {
	if (gt === void 0) {
		gt = window, _t = /Firefox/.test(navigator.userAgent);
		var e = Element.prototype, t = Node.prototype, n = Text.prototype;
		vt = a(t, "firstChild").get, yt = a(t, "nextSibling").get, l(e) && (e[de] = void 0, e[ue] = null, e[fe] = void 0, e.__e = void 0), l(n) && (n[pe] = void 0);
	}
}
function xt(e = "") {
	return document.createTextNode(e);
}
/*@__NO_SIDE_EFFECTS__*/
function St(e) {
	return vt.call(e);
}
/*@__NO_SIDE_EFFECTS__*/
function Ct(e) {
	return yt.call(e);
}
function wt(e, t) {
	return /* @__PURE__ */ St(e);
}
function Tt(e, t, n) {
	return t == null || t === "http://www.w3.org/1999/xhtml" ? n ? document.createElement(e, { is: n }) : document.createElement(e) : n ? document.createElementNS(t, e, { is: n }) : document.createElementNS(t, e);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/reactivity/effects.js
function Et(e, t) {
	var n = t.last;
	n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function R(e, t) {
	var n = W;
	n !== null && n.f & 8192 && (e |= ee);
	var r = {
		ctx: b,
		deps: null,
		nodes: null,
		f: e | m | 512,
		first: null,
		fn: t,
		last: null,
		next: null,
		parent: n,
		b: n && n.b,
		prev: null,
		teardown: null,
		wv: 0,
		ac: null
	};
	k?.register_created_effect(r);
	var i = r;
	if (e & 4) j === null ? it.ensure().schedule(r) : j.push(r);
	else if (t !== null) {
		try {
			Q(r);
		} catch (e) {
			throw z(r), e;
		}
		i.deps === null && i.teardown === null && i.nodes === null && i.first === i.last && !(i.f & 524288) && (i = i.first, e & 16 && e & 65536 && i !== null && (i.f |= ie));
	}
	if (i !== null && (i.parent = n, n !== null && Et(i, n), V !== null && V.f & 2 && !(e & 64))) {
		var a = V;
		(a.effects ??= []).push(i);
	}
	return r;
}
function Dt() {
	return V !== null && !H;
}
function Ot(e) {
	let t = R(8, null);
	return E(t, p), t.teardown = e, t;
}
function kt(e) {
	return R(4 | ae, e);
}
function At(e) {
	it.ensure();
	let t = R(64 | g, e);
	return (e = {}) => new Promise((n) => {
		e.outro ? Vt(t, () => {
			z(t), n(void 0);
		}) : (z(t), n(void 0));
	});
}
function jt(e) {
	return R(se | g, e);
}
function Mt(e, t = 0) {
	return R(8 | t, e);
}
function Nt(e, t = [], n = [], r = []) {
	ze(r, t, n, (t) => {
		R(8, () => {
			e(...t.map($));
		});
	});
}
function Pt(e, t = 0) {
	return R(16 | t, e);
}
function Ft(e) {
	return R(32 | g, e);
}
function It(e) {
	var t = e.teardown;
	if (t !== null) {
		let e = B, n = V;
		Kt(!0), U(null);
		try {
			t.call(null);
		} finally {
			Kt(e), U(n);
		}
	}
}
function Lt(e, t = !1) {
	var n = e.first;
	for (e.first = e.last = null; n !== null;) {
		let e = n.ac;
		e !== null && Pe(() => {
			e.abort(v);
		});
		var r = n.next;
		n.f & 64 ? n.parent = null : z(n, t), n = r;
	}
}
function Rt(e) {
	for (var t = e.first; t !== null;) {
		var n = t.next;
		t.f & 32 || z(t), t = n;
	}
}
function z(e, t = !0) {
	var n = !1;
	(t || e.f & 262144) && e.nodes !== null && e.nodes.end !== null && (zt(e.nodes.start, e.nodes.end), n = !0), e.f |= re, Lt(e, t && !n), nn(e, 0);
	var r = e.nodes && e.nodes.t;
	if (r !== null) for (let e of r) e.stop();
	It(e), e.f ^= re, e.f |= te;
	var i = e.parent;
	i !== null && i.first !== null && Bt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = e.b = null;
}
function zt(e, t) {
	for (; e !== null;) {
		var n = e === t ? null : /* @__PURE__ */ Ct(e);
		e.remove(), e = n;
	}
}
function Bt(e) {
	var t = e.parent, n = e.prev, r = e.next;
	n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function Vt(e, t, n = !0) {
	var r = [];
	Ht(e, r, !0);
	var i = () => {
		n && z(e), t && t();
	}, a = r.length;
	if (a > 0) {
		var o = () => --a || i();
		for (var s of r) s.out(o);
	} else i();
}
function Ht(e, t, n) {
	if (!(e.f & 8192)) {
		e.f ^= ee;
		var r = e.nodes && e.nodes.t;
		if (r !== null) for (let e of r) (e.is_global || n) && t.push(e);
		for (var i = e.first; i !== null;) {
			var a = i.next;
			if (!(i.f & 64)) {
				var o = !!(i.f & 65536) || !!(i.f & 32) && !!(e.f & 16);
				Ht(i, t, o ? n : !1);
			}
			i = a;
		}
	}
}
function Ut(e, t) {
	if (e.nodes) for (var n = e.nodes.start, r = e.nodes.end; n !== null;) {
		var i = n === r ? null : /* @__PURE__ */ Ct(n);
		t.append(n), n = i;
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/legacy.js
var Wt = null, Gt = !1, B = !1;
function Kt(e) {
	B = e;
}
var V = null, H = !1;
function U(e) {
	V = e;
}
var W = null;
function G(e) {
	W = e;
}
var K = null;
function qt(e) {
	V !== null && (K ??= /* @__PURE__ */ new Set()).add(e);
}
var q = null, J = 0, Y = null;
function Jt(e) {
	Y = e;
}
var Yt = 1, X = 0, Z = X;
function Xt(e) {
	Z = e;
}
function Zt() {
	return ++Yt;
}
function Qt(e) {
	var t = e.f;
	if (t & 2048) return !0;
	if (t & 2 && (e.f &= ~_), t & 4096) {
		for (var n = e.deps, r = n.length, i = 0; i < r; i++) {
			var a = n[i];
			if (Qt(a) && Je(a), a.wv > e.wv) return !0;
		}
		t & 512 && A === null && E(e, p);
	}
	return !1;
}
function $t(e, t, n = !0) {
	var r = e.reactions;
	if (r !== null && !(K !== null && K.has(e))) for (var i = 0; i < r.length; i++) {
		var a = r[i];
		a.f & 2 ? $t(a, t, !1) : t === a && (n ? E(a, m) : a.f & 1024 && E(a, h), st(a));
	}
}
function en(e) {
	var t = q, n = J, r = Y, i = V, a = K, o = b, s = H, c = Z, l = e.f;
	q = null, J = 0, Y = null, V = l & 96 ? null : e, K = null, x(e.ctx), H = !1, Z = ++X, e.ac !== null && (Pe(() => {
		e.ac.abort(v);
	}), e.ac = null);
	try {
		e.f |= oe;
		var u = e.fn, d = u();
		e.f |= ne;
		var f = e.deps, p = k?.is_fork;
		if (q !== null) {
			var m;
			if (p || nn(e, J), f !== null && J > 0) for (f.length = J + q.length, m = 0; m < q.length; m++) f[J + m] = q[m];
			else e.deps = f = q;
			if (Dt() && e.f & 512) for (m = J; m < f.length; m++) (f[m].reactions ??= []).push(e);
		} else !p && f !== null && J < f.length && (nn(e, J), f.length = J);
		if (S() && Y !== null && !H && f !== null && !(e.f & 6146)) for (m = 0; m < Y.length; m++) $t(Y[m], e);
		if (i !== null && i !== e) {
			if (X++, i.deps !== null) for (let e = 0; e < n; e += 1) i.deps[e].rv = X;
			if (t !== null) for (let e of t) e.rv = X;
			Y !== null && (r === null ? r = Y : r.push(...Y));
		}
		return e.f & 8388608 && (e.f ^= ce), d;
	} catch (e) {
		return ke(e);
	} finally {
		e.f ^= oe, q = t, J = n, Y = r, V = i, K = a, x(o), H = s, Z = c;
	}
}
function tn(e, r) {
	let i = r.reactions;
	if (i !== null) {
		var a = t.call(i, e);
		if (a !== -1) {
			var o = i.length - 1;
			o === 0 ? i = r.reactions = null : (i[a] = i[o], i.pop());
		}
	}
	if (i === null && r.f & 2 && (q === null || !n.call(q, r))) {
		var s = r;
		s.f & 512 && (s.f ^= 512, s.f &= ~_), s.v !== y && je(s), s.ac !== null && Pe(() => {
			s.ac.abort(v), s.ac = null, E(s, m);
		}), Ye(s), nn(s, 0);
	}
}
function nn(e, t) {
	var n = e.deps;
	if (n !== null) for (var r = t; r < n.length; r++) tn(e, n[r]);
}
function Q(e) {
	var t = e.f;
	if (!(t & 16384)) {
		E(e, p);
		var n = W, r = Gt;
		W = e, Gt = !(t & 96);
		try {
			t & 16777232 ? Rt(e) : Lt(e), It(e);
			var i = en(e);
			e.teardown = typeof i == "function" ? i : null, e.wv = Yt;
		} finally {
			Gt = r, W = n;
		}
	}
}
function $(e) {
	var t = !!(e.f & 2);
	if (Wt?.add(e), V !== null && !H && !(W !== null && W.f & 16384) && (K === null || !K.has(e))) {
		var r = V.deps;
		if (V.f & 2097152) e.rv < X && (e.rv = X, q === null && r !== null && r[J] === e ? J++ : q === null ? q = [e] : q.push(e));
		else {
			V.deps ??= [], n.call(V.deps, e) || V.deps.push(e);
			var i = e.reactions;
			i === null ? e.reactions = [V] : n.call(i, V) || i.push(V);
		}
	}
	if (B && N.has(e)) return N.get(e);
	if (t) {
		var a = e;
		if (B) {
			var o = a.v;
			return (!(a.f & 1024) && a.reactions !== null || an(a)) && (o = qe(a)), N.set(a, o), o;
		}
		var s = !(a.f & 512) && !H && V !== null && (Gt || !!(V.f & 512)), c = (a.f & ne) === 0;
		Qt(a) && (s && (a.f |= 512), Je(a)), s && !c && (Xe(a), rn(a));
	}
	if (A?.has(e)) return A.get(e);
	if (e.f & 8388608) throw e.v;
	return e.v;
}
function rn(e) {
	if (e.f |= 512, e.deps !== null) for (let t of e.deps) (t.reactions ??= []).push(e), t.f & 2 && !(t.f & 512) && (Xe(t), rn(t));
}
function an(e) {
	if (e.v === y) return !0;
	if (e.deps === null) return !1;
	for (let t of e.deps) if (N.has(t) || t.f & 2 && an(t)) return !0;
	return !1;
}
function on(e) {
	var t = H;
	try {
		return H = !0, e();
	} finally {
		H = t;
	}
}
[.../* @__PURE__ */ "allowfullscreen.async.autofocus.autoplay.checked.controls.default.disabled.formnovalidate.indeterminate.inert.ismap.loop.multiple.muted.nomodule.novalidate.open.playsinline.readonly.required.reversed.seamless.selected.webkitdirectory.defer.disablepictureinpicture.disableremoteplayback".split(".")];
var sn = ["touchstart", "touchmove"];
function cn(e) {
	return sn.includes(e);
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/elements/events.js
var ln = Symbol("events"), un = /* @__PURE__ */ new Set(), dn = /* @__PURE__ */ new Set(), fn = null;
function pn(e) {
	var t = this, n = t.ownerDocument, r = e.type, a = e.composedPath?.() || [], o = a[0] || e.target;
	fn = e;
	var s = 0, c = fn === e && e[ln];
	if (c) {
		var l = a.indexOf(c);
		if (l !== -1 && (t === document || t === window)) {
			e[ln] = t;
			return;
		}
		var u = a.indexOf(t);
		if (u === -1) return;
		l <= u && (s = l);
	}
	if (o = a[s] || e.target, o !== t) {
		i(e, "currentTarget", {
			configurable: !0,
			get() {
				return o || n;
			}
		});
		var d = V, f = W;
		U(null), G(null);
		try {
			for (var p, m = []; o !== null && o !== t;) {
				try {
					var h = o[ln]?.[r];
					h != null && (!o.disabled || e.target === o) && h.call(o, e);
				} catch (e) {
					p ? m.push(e) : p = e;
				}
				if (e.cancelBubble) break;
				s++, o = s < a.length ? a[s] : null;
			}
			if (p) {
				for (let e of m) queueMicrotask(() => {
					throw e;
				});
				throw p;
			}
		} finally {
			e[ln] = t, delete e.currentTarget, U(d), G(f);
		}
	}
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/reconciler.js
var mn = globalThis?.window?.trustedTypes && /* @__PURE__ */ globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", { createHTML: (e) => e });
function hn(e) {
	return mn?.createHTML(e) ?? e;
}
function gn(e) {
	var t = Tt("template");
	return t.innerHTML = hn(e.replaceAll("<!>", "<!---->")), t.content;
}
//#endregion
//#region frontend/node_modules/svelte/src/internal/client/dom/template.js
function _n(e, t) {
	var n = W;
	n.nodes === null && (n.nodes = {
		start: e,
		end: t,
		a: null,
		t: null
	});
}
/*#__NO_SIDE_EFFECTS__*/
function vn(e, t) {
	var n = !!(t & 1), r = !!(t & 2), i, a = !e.startsWith("<!>");
	return () => {
		i === void 0 && (i = gn(a ? e : "<!>" + e), n || (i = /* @__PURE__ */ St(i)));
		var t = r || _t ? document.importNode(i, !0) : i.cloneNode(!0);
		if (n) {
			var o = /* @__PURE__ */ St(t), s = t.lastChild;
			_n(o, s);
		} else _n(t, t);
		return t;
	};
}
function yn(e, t) {
	e !== null && e.before(t);
}
function bn(e, t) {
	var n = t == null ? "" : typeof t == "object" ? `${t}` : t;
	n !== (e[pe] ??= e.nodeValue) && (e[pe] = n, e.nodeValue = `${n}`);
}
function xn(e, t) {
	return Cn(e, t);
}
var Sn = /* @__PURE__ */ new Map();
function Cn(e, { target: t, anchor: n, props: i = {}, events: a, context: o, intro: s = !0, transformError: c }) {
	bt();
	var l = void 0, u = At(() => {
		var s = n ?? t.appendChild(xt());
		Le(s, { pending: () => {} }, (t) => {
			Ee({});
			var n = b;
			o && (n.c = o), a && (i.$$events = a), l = e(t, i) || {}, De();
		}, c);
		var u = /* @__PURE__ */ new Set(), d = (e) => {
			for (var n = 0; n < e.length; n++) {
				var r = e[n];
				if (!u.has(r)) {
					u.add(r);
					var i = cn(r);
					for (let e of [t, document]) {
						var a = Sn.get(e);
						a === void 0 && (a = /* @__PURE__ */ new Map(), Sn.set(e, a));
						var o = a.get(r);
						o === void 0 ? (e.addEventListener(r, pn, { passive: i }), a.set(r, 1)) : a.set(r, o + 1);
					}
				}
			}
		};
		return d(r(un)), dn.add(d), () => {
			for (var e of u) for (let n of [t, document]) {
				var r = Sn.get(n), i = r.get(e);
				--i == 0 ? (n.removeEventListener(e, pn), r.delete(e), r.size === 0 && Sn.delete(n)) : r.set(e, i);
			}
			dn.delete(d), s !== n && s.parentNode?.removeChild(s);
		};
	});
	return wn.set(l, u), l;
}
var wn = /* @__PURE__ */ new WeakMap();
function Tn(e, t) {
	let n = wn.get(e);
	return n ? (wn.delete(e), n(t)) : Promise.resolve();
}
//#endregion
export { vn as a, Se as c, yn as i, bn as n, Nt as o, Tn as r, wt as s, xn as t };
