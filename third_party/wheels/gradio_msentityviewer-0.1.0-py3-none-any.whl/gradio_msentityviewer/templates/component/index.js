import { A as e, C as t, D as n, E as r, F as i, I as a, M as o, N as s, O as c, P as l, S as u, T as d, _ as f, a as p, b as m, c as h, f as g, g as _, h as v, i as y, j as b, k as x, l as S, m as C, n as ee, o as te, r as ne, s as w, t as T, u as re, v as E, w as D, x as O, y as k } from "./index-client-CVlU5n3x.js";
//#region frontend/node_modules/@gradio/theme/dist/src/colors.js
var A = [
	{
		color: "red",
		primary: 600,
		secondary: 100
	},
	{
		color: "green",
		primary: 600,
		secondary: 100
	},
	{
		color: "blue",
		primary: 600,
		secondary: 100
	},
	{
		color: "yellow",
		primary: 500,
		secondary: 100
	},
	{
		color: "purple",
		primary: 600,
		secondary: 100
	},
	{
		color: "teal",
		primary: 600,
		secondary: 100
	},
	{
		color: "orange",
		primary: 600,
		secondary: 100
	},
	{
		color: "cyan",
		primary: 600,
		secondary: 100
	},
	{
		color: "lime",
		primary: 500,
		secondary: 100
	},
	{
		color: "pink",
		primary: 600,
		secondary: 100
	}
], j = {
	inherit: "inherit",
	current: "currentColor",
	transparent: "transparent",
	black: "#000",
	white: "#fff",
	slate: {
		50: "#f8fafc",
		100: "#f1f5f9",
		200: "#e2e8f0",
		300: "#cbd5e1",
		400: "#94a3b8",
		500: "#64748b",
		600: "#475569",
		700: "#334155",
		800: "#1e293b",
		900: "#0f172a",
		950: "#020617"
	},
	gray: {
		50: "#f9fafb",
		100: "#f3f4f6",
		200: "#e5e7eb",
		300: "#d1d5db",
		400: "#9ca3af",
		500: "#6b7280",
		600: "#4b5563",
		700: "#374151",
		800: "#1f2937",
		900: "#111827",
		950: "#030712"
	},
	zinc: {
		50: "#fafafa",
		100: "#f4f4f5",
		200: "#e4e4e7",
		300: "#d4d4d8",
		400: "#a1a1aa",
		500: "#71717a",
		600: "#52525b",
		700: "#3f3f46",
		800: "#27272a",
		900: "#18181b",
		950: "#09090b"
	},
	neutral: {
		50: "#fafafa",
		100: "#f5f5f5",
		200: "#e5e5e5",
		300: "#d4d4d4",
		400: "#a3a3a3",
		500: "#737373",
		600: "#525252",
		700: "#404040",
		800: "#262626",
		900: "#171717",
		950: "#0a0a0a"
	},
	stone: {
		50: "#fafaf9",
		100: "#f5f5f4",
		200: "#e7e5e4",
		300: "#d6d3d1",
		400: "#a8a29e",
		500: "#78716c",
		600: "#57534e",
		700: "#44403c",
		800: "#292524",
		900: "#1c1917",
		950: "#0c0a09"
	},
	red: {
		50: "#fef2f2",
		100: "#fee2e2",
		200: "#fecaca",
		300: "#fca5a5",
		400: "#f87171",
		500: "#ef4444",
		600: "#dc2626",
		700: "#b91c1c",
		800: "#991b1b",
		900: "#7f1d1d",
		950: "#450a0a"
	},
	orange: {
		50: "#fff7ed",
		100: "#ffedd5",
		200: "#fed7aa",
		300: "#fdba74",
		400: "#fb923c",
		500: "#f97316",
		600: "#ea580c",
		700: "#c2410c",
		800: "#9a3412",
		900: "#7c2d12",
		950: "#431407"
	},
	amber: {
		50: "#fffbeb",
		100: "#fef3c7",
		200: "#fde68a",
		300: "#fcd34d",
		400: "#fbbf24",
		500: "#f59e0b",
		600: "#d97706",
		700: "#b45309",
		800: "#92400e",
		900: "#78350f",
		950: "#451a03"
	},
	yellow: {
		50: "#fefce8",
		100: "#fef9c3",
		200: "#fef08a",
		300: "#fde047",
		400: "#facc15",
		500: "#eab308",
		600: "#ca8a04",
		700: "#a16207",
		800: "#854d0e",
		900: "#713f12",
		950: "#422006"
	},
	lime: {
		50: "#f7fee7",
		100: "#ecfccb",
		200: "#d9f99d",
		300: "#bef264",
		400: "#a3e635",
		500: "#84cc16",
		600: "#65a30d",
		700: "#4d7c0f",
		800: "#3f6212",
		900: "#365314",
		950: "#1a2e05"
	},
	green: {
		50: "#f0fdf4",
		100: "#dcfce7",
		200: "#bbf7d0",
		300: "#86efac",
		400: "#4ade80",
		500: "#22c55e",
		600: "#16a34a",
		700: "#15803d",
		800: "#166534",
		900: "#14532d",
		950: "#052e16"
	},
	emerald: {
		50: "#ecfdf5",
		100: "#d1fae5",
		200: "#a7f3d0",
		300: "#6ee7b7",
		400: "#34d399",
		500: "#10b981",
		600: "#059669",
		700: "#047857",
		800: "#065f46",
		900: "#064e3b",
		950: "#022c22"
	},
	teal: {
		50: "#f0fdfa",
		100: "#ccfbf1",
		200: "#99f6e4",
		300: "#5eead4",
		400: "#2dd4bf",
		500: "#14b8a6",
		600: "#0d9488",
		700: "#0f766e",
		800: "#115e59",
		900: "#134e4a",
		950: "#042f2e"
	},
	cyan: {
		50: "#ecfeff",
		100: "#cffafe",
		200: "#a5f3fc",
		300: "#67e8f9",
		400: "#22d3ee",
		500: "#06b6d4",
		600: "#0891b2",
		700: "#0e7490",
		800: "#155e75",
		900: "#164e63",
		950: "#083344"
	},
	sky: {
		50: "#f0f9ff",
		100: "#e0f2fe",
		200: "#bae6fd",
		300: "#7dd3fc",
		400: "#38bdf8",
		500: "#0ea5e9",
		600: "#0284c7",
		700: "#0369a1",
		800: "#075985",
		900: "#0c4a6e",
		950: "#082f49"
	},
	blue: {
		50: "#eff6ff",
		100: "#dbeafe",
		200: "#bfdbfe",
		300: "#93c5fd",
		400: "#60a5fa",
		500: "#3b82f6",
		600: "#2563eb",
		700: "#1d4ed8",
		800: "#1e40af",
		900: "#1e3a8a",
		950: "#172554"
	},
	indigo: {
		50: "#eef2ff",
		100: "#e0e7ff",
		200: "#c7d2fe",
		300: "#a5b4fc",
		400: "#818cf8",
		500: "#6366f1",
		600: "#4f46e5",
		700: "#4338ca",
		800: "#3730a3",
		900: "#312e81",
		950: "#1e1b4b"
	},
	violet: {
		50: "#f5f3ff",
		100: "#ede9fe",
		200: "#ddd6fe",
		300: "#c4b5fd",
		400: "#a78bfa",
		500: "#8b5cf6",
		600: "#7c3aed",
		700: "#6d28d9",
		800: "#5b21b6",
		900: "#4c1d95",
		950: "#2e1065"
	},
	purple: {
		50: "#faf5ff",
		100: "#f3e8ff",
		200: "#e9d5ff",
		300: "#d8b4fe",
		400: "#c084fc",
		500: "#a855f7",
		600: "#9333ea",
		700: "#7e22ce",
		800: "#6b21a8",
		900: "#581c87",
		950: "#3b0764"
	},
	fuchsia: {
		50: "#fdf4ff",
		100: "#fae8ff",
		200: "#f5d0fe",
		300: "#f0abfc",
		400: "#e879f9",
		500: "#d946ef",
		600: "#c026d3",
		700: "#a21caf",
		800: "#86198f",
		900: "#701a75",
		950: "#4a044e"
	},
	pink: {
		50: "#fdf2f8",
		100: "#fce7f3",
		200: "#fbcfe8",
		300: "#f9a8d4",
		400: "#f472b6",
		500: "#ec4899",
		600: "#db2777",
		700: "#be185d",
		800: "#9d174d",
		900: "#831843",
		950: "#500724"
	},
	rose: {
		50: "#fff1f2",
		100: "#ffe4e6",
		200: "#fecdd3",
		300: "#fda4af",
		400: "#fb7185",
		500: "#f43f5e",
		600: "#e11d48",
		700: "#be123c",
		800: "#9f1239",
		900: "#881337",
		950: "#4c0519"
	}
};
A.reduce((e, { color: t, primary: n, secondary: r }) => ({
	...e,
	[t]: {
		primary: j[t][n],
		secondary: j[t][r]
	}
}), {});
//#endregion
//#region frontend/node_modules/svelte/src/store/index-client.js
function M(t) {
	let n, r = e((e) => {
		let r = !1, i = t.subscribe((t) => {
			n = t, r && e();
		});
		return r = !0, i;
	});
	function i() {
		return m() ? (r(), n) : b(t);
	}
	return "set" in t ? {
		get current() {
			return i();
		},
		set current(e) {
			t.set(e);
		}
	} : { get current() {
		return i();
	} };
}
var N = [
	"label",
	"info",
	"placeholder",
	"description",
	"title",
	"value"
], P = /* @__PURE__ */ "elem_id.elem_classes.visible.interactive.server_fns.server.id.target.theme_mode.version.root.autoscroll.max_file_size.formatter.client.load_component.scale.min_width.theme.padding.loading_status.label.show_label.validation_error.show_progress.api_prefix.container.attached_events.register_component.unregister_component.dispatcher".split(".");
function F(e) {
	return typeof e == "string" && e.includes("__i18n__");
}
var ie = class {
	load_component;
	#e = c(r({}));
	get shared() {
		return E(this.#e);
	}
	set shared(e) {
		n(this.#e, e, !0);
	}
	#t = c(r({}));
	get props() {
		return E(this.#t);
	}
	set props(e) {
		n(this.#t, e, !0);
	}
	#n = c((e) => e);
	get i18n() {
		return E(this.#n);
	}
	set i18n(e) {
		n(this.#n, e, !0);
	}
	i18n_store;
	_i18n_from_store;
	translatable_props = {};
	dispatcher;
	last_update = null;
	shared_props = P;
	mounted = !1;
	old_value;
	register_component;
	unregister_component;
	set_data_callback;
	get_data_callback;
	registered_id = null;
	last_shared_props;
	last_props;
	constructor(e, t) {
		for (let t in e.shared_props) this.shared[t] = e.shared_props[t];
		for (let t in e.props) t !== "i18n_store" && (this.props[t] = e.props[t]);
		if (t) for (let e in t) this.props[e] === void 0 && (this.props[e] = t[e]);
		this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? M(this.i18n_store) : void 0;
		for (let t of N) this.shared[t] = this._translate_and_store("shared", t, e.shared_props[t]), this.props[t] = this._translate_and_store("props", t, e.props[t]);
		this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {}), this.unregister_component = this.shared.unregister_component || (() => {}), this.dispatcher = this.shared.dispatcher || (() => {}), this.set_data_callback = this.set_data.bind(this), this.get_data_callback = this.get_data.bind(this), this.register_component(this.shared.id, this.set_data_callback, this.get_data_callback), this.registered_id = this.shared.id, this.last_shared_props = e.shared_props, this.last_props = e.props, u(() => {
			let t = e.shared_props.id;
			if (this.last_shared_props !== e.shared_props) {
				for (let t in e.shared_props) {
					let n = e.shared_props[t];
					n !== void 0 && (this._is_i18n_managed(`shared.${t}`, n) || (this.shared[t] = n));
				}
				this.last_shared_props = e.shared_props;
			}
			if (this.last_props !== e.props) {
				for (let t in e.props) {
					if (t === "i18n_store") continue;
					let n = e.props[t];
					n !== void 0 && (this._is_i18n_managed(`props.${t}`, n) || (this.props[t] = n));
				}
				this.last_props = e.props;
			}
			this.registered_id !== null && this.registered_id !== t && this.unregister_component(this.registered_id, this.set_data_callback), this.register_component(t, this.set_data_callback, this.get_data_callback), this.registered_id = t, k(() => {
				this.shared.id = t;
			});
		}), u(() => () => {
			this.registered_id !== null && this.unregister_component(this.registered_id, this.set_data_callback);
		}), u(() => {
			if (this.i18n_store) return this.i18n_store.subscribe(() => {
				for (let [e, t] of Object.entries(this.translatable_props)) {
					let [n, r] = e.split("."), i = this.i18n(t);
					n === "shared" ? this.shared[r] = i : this.props[r] = i;
				}
			});
		});
	}
	_is_i18n_managed(e, t) {
		let n = this.translatable_props[e];
		return n ? t === n || (delete this.translatable_props[e], !1) : !1;
	}
	_translate_and_store(e, t, n) {
		if (typeof n != "string") return n;
		let r = this.i18n(n);
		return r !== n && (this.translatable_props[`${e}.${t}`] = n), r;
	}
	live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
	dispatch(e, t) {
		this.dispatcher(this.shared.id, e, t);
	}
	async get_data() {
		return l(this.props);
	}
	update(e) {
		this.set_data(e);
	}
	set_data(e) {
		for (let t in e) {
			let n = e[t], r = F(n) ? this._translate_and_store(this.shared_props.includes(t) ? "shared" : "props", t, n) : n;
			if (this.shared_props.includes(t)) {
				let e = t;
				this.shared[e] = r;
				continue;
			}
			this.props[t] = r;
		}
	}
	watch_for_change() {
		u(() => {
			this.mounted ||= (this.old_value = this.props.value, !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
		});
	}
}, ae = /* @__PURE__ */ new Set([
	"$$slots",
	"$$events",
	"$$legacy"
]), oe = _("<div class=\"label svelte-r41nsf\"> </div>"), se = _("<button type=\"button\" class=\"column-option svelte-r41nsf\"><span>✓</span><span class=\"svelte-r41nsf\"> </span></button>"), ce = _("<th class=\"svelte-r41nsf\"> </th>"), le = _("<td class=\"svelte-r41nsf\"> </td>"), ue = _("<tr class=\"svelte-r41nsf\"><td class=\"row-column svelte-r41nsf\"> </td><td class=\"spectrum-column svelte-r41nsf\"><button class=\"spectrum-button svelte-r41nsf\"><svg viewBox=\"0 0 28 22\" class=\"svelte-r41nsf\"><path d=\"M2 19h24M4 18V13m4 5V7m4 11v-4m4 4V3m4 15V9m4 9v-7\"></path></svg></button></td><!></tr>"), de = _("<tr class=\"svelte-r41nsf\"><td class=\"empty svelte-r41nsf\">No spectra match this search.</td></tr>"), fe = _("<div><div class=\"toolbar svelte-r41nsf\"><div><!><div class=\"summary svelte-r41nsf\"> </div></div><div class=\"tools svelte-r41nsf\"><details class=\"svelte-r41nsf\"><summary class=\"svelte-r41nsf\">Columns</summary><div class=\"column-menu svelte-r41nsf\"><button type=\"button\" class=\"column-option all svelte-r41nsf\"><span>✓</span><span class=\"svelte-r41nsf\">All columns</span></button><!></div></details><label class=\"search svelte-r41nsf\"><span class=\"svelte-r41nsf\">Search current page</span><input placeholder=\"Filter current page…\" class=\"svelte-r41nsf\"/></label></div></div> <div class=\"table-wrap svelte-r41nsf\"><table class=\"svelte-r41nsf\"><thead><tr><th class=\"row-column svelte-r41nsf\">Row</th><th class=\"spectrum-column svelte-r41nsf\">Spectrum</th><!></tr></thead><tbody class=\"svelte-r41nsf\"></tbody></table></div> <div class=\"pagination svelte-r41nsf\"><span class=\"svelte-r41nsf\"> </span><div class=\"page-controls svelte-r41nsf\"><button class=\"svelte-r41nsf\">‹</button><span class=\"svelte-r41nsf\"><input type=\"number\" min=\"1\" class=\"svelte-r41nsf\"/> </span><button class=\"svelte-r41nsf\">›</button></div><span class=\"svelte-r41nsf\"> </span></div></div>");
function I(e, l) {
	s(l, !0);
	let m = new ie(T(l, ae));
	m.watch_for_change();
	let _ = c(""), b = c(r([])), k = c(""), A = null, j = c(!1), M = x(() => m.props.value), N = x(() => Array.isArray(E(M) === null || E(M) === void 0 ? void 0 : E(M).columns) ? E(M).columns.map(String) : []);
	u(() => {
		let e = JSON.stringify(E(N));
		if (e !== E(k)) {
			n(k, e, !0);
			let t = m.props.initial_columns;
			n(b, Array.isArray(t) ? E(N).filter((e) => t.includes(e)) : [...E(N)], !0);
		}
	});
	let P = x(() => Array.isArray(E(M) === null || E(M) === void 0 ? void 0 : E(M).rows) ? E(M).rows : []), F = x(() => Array.isArray(E(M) === null || E(M) === void 0 ? void 0 : E(M).spectra) ? E(M).spectra : []), I = x(() => Number.isInteger(E(M) === null || E(M) === void 0 ? void 0 : E(M).page) ? E(M).page : 0), L = x(() => m.props.page_size ?? 20), R = x(() => Number.isInteger(E(M) === null || E(M) === void 0 ? void 0 : E(M).row_offset) ? E(M).row_offset : E(I) * E(L)), z = x(() => Number.isInteger(E(M) === null || E(M) === void 0 ? void 0 : E(M).total_rows) ? E(M).total_rows : E(P).length), pe = x(() => Number.isInteger(E(M) === null || E(M) === void 0 ? void 0 : E(M).page_size) ? E(M).page_size : Number.isInteger(E(L)) && E(L) > 0 ? E(L) : 20), B = x(() => E(_).trim().toLocaleLowerCase()), V = x(() => E(P).map((e, t) => ({
		row: e,
		index: t
	})).filter(({ row: e }) => !E(B) || E(N).some((t) => String(e?.[t] ?? "").toLocaleLowerCase().includes(E(B))))), H = x(() => Number.isInteger(E(M) === null || E(M) === void 0 ? void 0 : E(M).total_pages) ? E(M).total_pages : Math.max(1, Math.ceil(E(z) / E(pe)))), me = x(() => E(V)), U = (e, t) => typeof e == "number" ? `${e}px` : e || t, he = x(() => U(m.props.width, "100%")), ge = x(() => U(m.props.height, "auto"));
	u(() => {
		(E(M) === null || E(M) === void 0 ? void 0 : E(M).page) !== void 0 && n(j, !1);
	});
	let W = (e) => String(e ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#039;"), G = (e) => e == null ? "—" : typeof e == "object" ? JSON.stringify(e) : String(e), K = (e, t) => String(e?.Name ?? e?.name ?? e?.TITLE ?? e?.Title ?? e?.ID ?? e?.id ?? `Spectrum ${t + 1}`);
	function _e(e) {
		n(b, E(b).includes(e) ? E(b).filter((t) => t !== e) : E(N).filter((t) => t === e || E(b).includes(t)), !0);
	}
	function q(e) {
		let t = Math.min(E(H) - 1, Math.max(0, e));
		t === E(I) || E(j) || (n(j, !0), m.props.value = Object.assign(Object.assign({}, E(M)), { _page_request: t }), m.dispatch("page_request", { page: t }));
	}
	function ve(e) {
		let t = Number.parseInt(e, 10);
		Number.isFinite(t) && q(t - 1);
	}
	function ye(e, t) {
		let n = Array.isArray(t.mz) ? t.mz.map(Number) : [], r = Array.isArray(t.intensity) ? t.intensity.map(Number) : [], i = n.map((e, t) => ({
			x: e,
			y: r[t] ?? 0,
			index: t
		})).filter((e) => Number.isFinite(e.x) && Number.isFinite(e.y)), a = e.document.querySelector("#plot-root"), o = e.document.querySelector("#peak-body"), s = e.document.querySelector("#reset-zoom"), c = e.document.querySelector("#sort-mz"), l = e.document.querySelector("#sort-intensity");
		if (!a || !o || !s || !c || !l) return;
		let u = i.length ? Math.min(...i.map((e) => e.x)) : 0, d = i.length ? Math.max(...i.map((e) => e.x)) : 1, f = Math.max(1, d - u), p = [Math.max(0, u - f * .03), d + f * .06], m = [...p], h = null, g = null, _ = null, v = null, y = "mz", b = !0, x = (t) => {
			var n;
			h = t, S(), (n = e.document.querySelector(`[data-row="${t}"]`)) == null || n.scrollIntoView({ block: "nearest" });
		}, S = () => {
			let e = i.filter((e) => e.x >= m[0] && e.x <= m[1]), t = Math.max(1, ...e.map((e) => Math.max(0, e.y))) * 1.08, n = (e) => 72 + (e - m[0]) / (m[1] - m[0]) * 796, r = (e) => 478 - Math.max(0, e) / t * 448, s = "";
			for (let e = 0; e <= 5; e++) {
				let n = 72 + e / 5 * 796, r = 30 + e / 5 * 448;
				s += `<line x1="${n}" y1="30" x2="${n}" y2="478" class="grid"/><text x="${n}" y="504" text-anchor="middle">${(m[0] + e / 5 * (m[1] - m[0])).toFixed(1)}</text><line x1="72" y1="${r}" x2="868" y2="${r}" class="grid"/><text x="62" y="${r + 4}" text-anchor="end">${(t * (1 - e / 5)).toFixed(+(t < 10))}</text>`;
			}
			let u = e.map((e) => `<line data-peak="${e.index}" x1="${n(e.x)}" y1="478" x2="${n(e.x)}" y2="${r(e.y)}" class="peak ${h === e.index ? "selected" : ""}"><title>m/z ${e.x} · intensity ${e.y}</title></line>`).join("");
			a.innerHTML = `<svg id="spectrum-svg" viewBox="0 0 900 540"><style>text{font:13px system-ui;fill:#667085}.grid{stroke:#e4e7ec}.peak{stroke:#7c3aed;stroke-width:2;cursor:pointer}.peak:hover,.peak.selected{stroke:#e11d48;stroke-width:4}.axis{stroke:#344054;stroke-width:1.5}.axis-title{font-weight:600;fill:#344054}.selection{fill:#7c3aed22;stroke:#7c3aed;stroke-dasharray:5 3;pointer-events:none}</style>${s}<line x1="72" y1="478" x2="868" y2="478" class="axis"/><line x1="72" y1="30" x2="72" y2="478" class="axis"/>${u}<rect id="drag-box" x="72" y="30" width="0" height="448" class="selection"/><text x="470" y="528" text-anchor="middle" class="axis-title">m/z</text><text transform="translate(17 254) rotate(-90)" text-anchor="middle" class="axis-title">Intensity</text></svg>`;
			let d = [...i].sort((e, t) => (y === "mz" ? e.x - t.x : e.y - t.y) * (b ? 1 : -1));
			o.innerHTML = d.map((e) => `<tr data-row="${e.index}" class="${h === e.index ? "selected" : ""}"><td><button data-button="${e.index}">${e.x.toFixed(5)}</button></td><td><button data-button="${e.index}">${e.y.toLocaleString()}</button></td></tr>`).join(""), c.textContent = `m/z ${y === "mz" ? b ? "↑" : "↓" : ""}`, l.textContent = `Intensity ${y === "intensity" ? b ? "↑" : "↓" : ""}`, a.querySelectorAll("[data-peak]").forEach((e) => e.addEventListener("click", (t) => {
				t.stopPropagation(), x(Number(e.dataset.peak));
			})), o.querySelectorAll("[data-button]").forEach((e) => e.addEventListener("click", () => x(Number(e.dataset.button))));
			let f = a.querySelector("#spectrum-svg");
			if (!f) return;
			let p = (e) => {
				let t = f.getBoundingClientRect();
				return Math.min(868, Math.max(72, (e.clientX - t.left) / t.width * 900));
			};
			f.addEventListener("pointerdown", (e) => {
				var t;
				let n = (t = e.target).closest?.call(t, "[data-peak]");
				v = n ? Number(n.dataset.peak) : null, g = p(e), _ = g, f.setPointerCapture(e.pointerId);
			}), f.addEventListener("pointermove", (e) => {
				if (g === null) return;
				_ = p(e);
				let t = f.querySelector("#drag-box");
				t && (t.setAttribute("x", String(Math.min(g, _))), t.setAttribute("width", String(Math.abs(_ - g))));
			}), f.addEventListener("pointerup", () => {
				let e = g !== null && _ !== null && Math.abs(_ - g) > 8;
				if (e) {
					let e = (e) => m[0] + (e - 72) / 796 * (m[1] - m[0]);
					m = [e(Math.min(g, _)), e(Math.max(g, _))];
				}
				let t = v;
				g = null, _ = null, v = null, e ? S() : t === null ? f.querySelector("#drag-box")?.setAttribute("width", "0") : x(t);
			});
		}, C = (e) => {
			y === e ? b = !b : (y = e, b = !0), S();
		};
		c.onclick = () => C("mz"), l.onclick = () => C("intensity"), s.onclick = () => {
			m = [...p], g = null, _ = null, S();
		}, S();
	}
	function be(e) {
		let t = E(F)[e] ?? {
			mz: [],
			intensity: []
		}, n = E(P)[e] ?? {};
		if ((!A || A.closed) && (A = window.open("", "msentity-spectrum-viewer", "popup=yes,width=1280,height=760,resizable=yes,scrollbars=yes")), !A) return;
		let r = E(R) + e, i = K(n, r), a = E(N).map((e) => `<div><dt>${W(e)}</dt><dd>${W(G(n[e]))}</dd></div>`).join("");
		A.document.body.innerHTML = `<main><header><div><span class="eyebrow">MSENTITY · SPECTRUM ${r + 1}</span><h1>${W(i)}</h1></div><div class="actions"><span>${t?.mz?.length ?? 0} peaks</span><button id="reset-zoom">Reset zoom</button></div></header><div class="workspace"><section class="plot" id="plot-root"></section><aside><h2>Peaks</h2><div class="peak-scroll"><table><thead><tr><th><button id="sort-mz">m/z ↑</button></th><th><button id="sort-intensity">Intensity</button></th></tr></thead><tbody id="peak-body"></tbody></table></div></aside></div><section class="metadata"><h2>Metadata</h2><dl>${a}</dl></section></main>`;
		let o = A.document.createElement("style");
		o.textContent = "*{box-sizing:border-box}body{margin:0;background:#f8fafc;color:#101828;font-family:Inter,system-ui,sans-serif}main{max-width:1380px;margin:auto;padding:28px}header{display:flex;align-items:end;justify-content:space-between;margin-bottom:18px}.eyebrow{font-size:12px;font-weight:700;letter-spacing:.1em;color:#7c3aed}h1{margin:5px 0 0;font-size:26px}h2{font-size:16px;margin:0 0 12px}.actions{display:flex;gap:12px;align-items:center;color:#667085}.actions button{border:1px solid #d0d5dd;border-radius:8px;background:white;padding:7px 11px;cursor:pointer}.workspace{display:grid;grid-template-columns:minmax(0,1fr) 280px;gap:16px}.plot,aside,.metadata{background:white;border:1px solid #e4e7ec;border-radius:14px;box-shadow:0 1px 3px #10182812}.plot{padding:8px;touch-action:none}.plot svg{display:block;width:100%;height:auto;user-select:none}aside{padding:16px;min-width:0}.peak-scroll{max-height:535px;overflow:auto}table{width:100%;border-collapse:collapse;font-size:12px}th{position:sticky;top:0;background:#fff;text-align:right;padding:0;border-bottom:1px solid #e4e7ec}th button{width:100%;border:0;background:#fff;padding:8px 6px;text-align:right;font-weight:650;color:#475467;cursor:pointer}th button:hover{background:#f9f5ff;color:#6941c6}td{text-align:right;padding:3px 6px;border-bottom:1px solid #f2f4f7}td button{width:100%;border:0;background:none;color:#6941c6;text-align:right;cursor:pointer;padding:3px}tr:hover,tr.selected{background:#fff1f2}tr.selected button{color:#e11d48;font-weight:700}.metadata{padding:18px;margin-top:16px}.metadata dl{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin:0}.metadata dt{font-size:12px;color:#667085}.metadata dd{margin:0;overflow-wrap:anywhere}@media(max-width:850px){main{padding:14px}.workspace{grid-template-columns:1fr}.peak-scroll{max-height:260px}header{align-items:start;flex-direction:column}}";
		let s = A.document.createElement("title");
		s.textContent = `${i} · Mass spectrum`, A.document.head.replaceChildren(s, o), ye(A, t), A.focus(), m.dispatch("select", {
			index: r,
			metadata: n
		});
	}
	var J = v(), Y = D(J), X = (e) => {
		var r = fe();
		let o;
		var s = t(r), c = t(s), l = t(c), u = (e) => {
			var n = oe(), r = t(n, !0);
			a(n), O(() => g(r, m.props.label)), C(e, n);
		};
		re(l, (e) => {
			m.props.label && e(u);
		});
		var v = d(l), x = t(v);
		a(v), a(c);
		var T = d(c), D = t(T), k = d(t(D)), A = t(k), F = t(A);
		let ie;
		i(), a(A);
		var ae = d(A);
		h(ae, 17, () => E(N), S, (e, n) => {
			var r = se(), i = t(r);
			let o;
			var s = d(i), c = t(s, !0);
			a(s), a(r), O((e, t) => {
				y(r, "aria-pressed", e), o = w(i, 1, "checkmark svelte-r41nsf", null, o, t), g(c, E(n));
			}, [() => E(b).includes(E(n)), () => ({ checked: E(b).includes(E(n)) })]), f("click", r, () => _e(E(n))), C(e, r);
		}), a(k), a(D);
		var L = d(D), B = d(t(L));
		ne(B), a(L), a(T), a(s);
		var V = d(s, 2), U = t(V), W = t(U), K = t(W), ye = d(t(K), 2);
		h(ye, 17, () => E(b), S, (e, n) => {
			var r = ce(), i = t(r, !0);
			a(r), O(() => g(i, E(n))), C(e, r);
		}), a(K), a(W);
		var J = d(W);
		h(J, 21, () => E(me), S, (e, n) => {
			var r = ue(), i = t(r), o = t(i, !0);
			a(i);
			var s = d(i), c = t(s);
			a(s);
			var l = d(s);
			h(l, 17, () => E(b), S, (e, r) => {
				var i = le(), o = t(i, !0);
				a(i), O((e, t) => {
					y(i, "title", e), g(o, t);
				}, [() => G(E(n).row?.[E(r)]), () => G(E(n).row?.[E(r)])]), C(e, i);
			}), a(r), O(() => {
				g(o, E(R) + E(n).index + 1), y(c, "title", `Open spectrum ${E(R) + E(n).index + 1}`);
			}), f("click", c, () => be(E(n).index)), C(e, r);
		}, (e) => {
			var n = de(), r = t(n);
			a(n), O(() => y(r, "colspan", E(b).length + 2)), C(e, n);
		}), a(J), a(U), a(V);
		var Y = d(V, 2), X = t(Y), xe = t(X);
		a(X);
		var Z = d(X), Se = t(Z), Q = d(Se), $ = t(Q);
		ne($);
		var Ce = d($);
		a(Q);
		var we = d(Q);
		a(Z);
		var Te = d(Z), Ee = t(Te, !0);
		a(Te), a(Y), a(r), O((e, t) => {
			y(r, "id", m.shared.elem_id ?? ""), o = w(r, 1, `msentity-viewer ${e ?? ""}`, "svelte-r41nsf", o, {
				invisible: m.shared.visible === "hidden",
				"fixed-height": m.props.height != null
			}), te(r, `width:${E(he)};height:${E(ge)}`), g(x, `${t ?? ""} spectra · ${E(b).length ?? ""}/${E(N).length ?? ""} columns${E(M)?.description ? ` · ${E(M).description}` : ""}`), y(A, "aria-pressed", E(b).length === E(N).length && E(N).length > 0), ie = w(F, 1, "checkmark svelte-r41nsf", null, ie, { checked: E(b).length === E(N).length && E(N).length > 0 }), g(xe, `${E(P).length ? E(R) + 1 : 0}–${E(R) + E(P).length} of ${E(z) ?? ""}`), Se.disabled = E(I) === 0 || E(j), y($, "max", E(H)), p($, E(I) + 1), $.disabled = E(j), g(Ce, ` / ${E(H) ?? ""}`), we.disabled = E(I) >= E(H) - 1 || E(j), g(Ee, E(j) ? "Loading…" : `${E(pe)} rows/page`);
		}, [() => (m.shared.elem_classes ?? []).join(" "), () => E(z).toLocaleString()]), f("click", A, () => n(b, E(b).length === E(N).length ? [] : [...E(N)], !0)), ee(B, () => E(_), (e) => n(_, e)), f("click", Se, () => q(E(I) - 1)), f("change", $, (e) => ve(e.currentTarget.value)), f("keydown", $, (e) => e.key === "Enter" && ve(e.currentTarget.value)), f("click", we, () => q(E(I) + 1)), C(e, r);
	};
	re(Y, (e) => {
		m.shared.visible !== !1 && e(X);
	}), C(e, J), o();
}
//#endregion
export { I as default };
