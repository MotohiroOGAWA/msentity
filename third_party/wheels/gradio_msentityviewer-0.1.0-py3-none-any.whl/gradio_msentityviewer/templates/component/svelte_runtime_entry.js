import { d as e, p as t } from "./index-client-CVlU5n3x.js";
//#region \0rolldown/runtime.js
var n = Object.defineProperty, r = /* @__PURE__ */ ((e, t) => {
	let r = {};
	for (var i in e) n(r, i, {
		get: e[i],
		enumerable: !0
	});
	return t || n(r, Symbol.toStringTag, { value: "Module" }), r;
})({});
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
//#endregion
export { r as SVELTE_VERSION, e as mount, t as unmount };
