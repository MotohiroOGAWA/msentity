from __future__ import annotations

import math
from datetime import date, datetime
from typing import Any

from gradio.components.base import Component
from gradio.context import get_blocks_context


def _json_value(value: Any) -> Any:
    """Convert pandas/numpy scalar values to JSON-safe Python values."""
    if value is None:
        return None
    if hasattr(value, "item"):
        try:
            value = value.item()
        except (TypeError, ValueError):
            pass
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(v) for v in value]
    if hasattr(value, "tolist"):
        return _json_value(value.tolist())
    return str(value)


class MSEntityViewer(Component):
    """Display an msentity MSDataset as a searchable spectrum table.

    Each row contains a spectrum button. Clicking it opens (or reuses) a separate
    browser window and switches that window to the selected mass spectrum.
    """

    EVENTS = ["change", "select", "page_request"]

    def __init__(
        self,
        value: Any = None,
        *,
        page_size: int = 20,
        initial_page: int = 1,
        initial_columns: list[str] | None = None,
        width: int | str | None = None,
        height: int | str | None = None,
        label: str | None = None,
        scale: int | None = 1,
        min_width: int | None = None,
        **kwargs: Any,
    ) -> None:
        if isinstance(page_size, bool) or not isinstance(page_size, int) or page_size < 1:
            raise ValueError("page_size must be a positive integer")
        if isinstance(initial_page, bool) or not isinstance(initial_page, int) or initial_page < 1:
            raise ValueError("initial_page must be a positive integer")
        if initial_columns is not None and (
            not isinstance(initial_columns, list)
            or any(not isinstance(column, str) for column in initial_columns)
        ):
            raise TypeError("initial_columns must be a list of column names or None")
        for name, dimension in (("width", width), ("height", height)):
            if dimension is not None and not isinstance(dimension, (int, str)):
                raise TypeError(f"{name} must be an integer, CSS string, or None")
            if isinstance(dimension, int) and dimension < 1:
                raise ValueError(f"{name} must be positive")
        self.page_size = page_size
        self.initial_page = initial_page
        self.initial_columns = initial_columns
        self.width = width
        self.height = height
        self._dataset: Any = None
        super().__init__(
            value=value,
            label=label,
            scale=scale,
            min_width=min_width,
            **kwargs,
        )
        if get_blocks_context() is not None:
            self.page_request(
                self._load_page,
                inputs=self,
                outputs=self,
                queue=False,
                show_progress="hidden",
                api_visibility="private",
            )

    def _load_page(self, payload: Any) -> dict[str, Any]:
        if self._dataset is None:
            return self._empty_page()
        requested = payload.get("_page_request", 0) if isinstance(payload, dict) else 0
        try:
            page = max(0, int(requested))
        except (TypeError, ValueError):
            page = 0
        return self._serialize_page(self._dataset, page)

    def _empty_page(self) -> dict[str, Any]:
        return {
            "columns": [], "rows": [], "spectra": [], "page": 0,
            "page_size": self.page_size, "total_rows": 0, "total_pages": 1,
            "row_offset": 0, "description": "", "attributes": {}, "tags": [],
        }

    def _serialize_page(self, dataset: Any, page: int) -> dict[str, Any]:
        total_rows = len(dataset)
        total_pages = max(1, math.ceil(total_rows / self.page_size))
        page = min(max(0, page), total_pages - 1)
        start = page * self.page_size
        stop = min(start + self.page_size, total_rows)

        # MSDataset slicing creates a view. Only metadata and peaks belonging to
        # the requested page are materialized and converted to JSON.
        page_view = dataset[start:stop]
        metadata = page_view.metadata.reset_index(drop=True)
        rows = [
            {str(key): _json_value(cell) for key, cell in row.items()}
            for row in metadata.to_dict(orient="records")
        ]
        spectra = [
            {
                "index": start + local_index,
                "mz": _json_value(spectrum.mz),
                "intensity": _json_value(spectrum.intensity),
            }
            for local_index, spectrum in enumerate(page_view.peaks)
        ]
        return {
            "columns": [str(column) for column in metadata.columns],
            "rows": rows,
            "spectra": spectra,
            "page": page,
            "page_size": self.page_size,
            "total_rows": total_rows,
            "total_pages": total_pages,
            "row_offset": start,
            "description": dataset.description,
            "attributes": _json_value(dataset.attributes),
            "tags": _json_value(dataset.tags),
        }

    def preprocess(self, payload: Any) -> Any:
        return payload

    def postprocess(self, value: Any) -> dict[str, Any] | None:
        if value is None:
            return None
        if isinstance(value, dict):
            return _json_value(value)

        # Avoid a hard import at module load time so API/docs generation remains
        # usable even when msentity is installed after this package.
        try:
            from msentity import MSDataset
        except ImportError as exc:  # pragma: no cover - installation guard
            raise ImportError(
                "MSEntityViewer requires msentity. Install this package with its dependencies."
            ) from exc

        if not isinstance(value, MSDataset):
            raise TypeError("value must be an msentity.MSDataset, a compatible dict, or None")
        self._dataset = value
        return self._serialize_page(value, self.initial_page - 1)

    def api_info(self) -> dict[str, Any]:
        return {"type": "object", "description": "Serialized msentity dataset."}

    def example_payload(self) -> dict[str, Any]:
        return {"index": 0, "metadata": {"Name": "Caffeine"}}

    def example_value(self) -> dict[str, Any]:
        return {
            "columns": ["Name", "PrecursorMZ", "IonMode"],
            "rows": [
                {"Name": "Caffeine", "PrecursorMZ": 195.0877, "IonMode": "POSITIVE"},
                {"Name": "Benzoic acid", "PrecursorMZ": 121.0295, "IonMode": "NEGATIVE"},
            ],
            "spectra": [
                {"index": 0, "mz": [55.0, 110.071, 138.066, 195.088], "intensity": [8, 24, 100, 62]},
                {"index": 1, "mz": [51.0, 77.039, 105.034, 121.03], "intensity": [12, 100, 48, 72]},
            ],
            "description": "Example mass spectra",
            "attributes": {},
            "tags": ["demo"],
        }
